[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/ckY2ssck)
# Parcial 2: Computación en internet I

Docentes: Alejandro Muñoz, Nicolas Salazar y Santiago Guitierrez.

Entrega: jueves, 16 de octubre

Tiempo para desarrollarlo: 1 hora y 40 minutos



## Consideraciones y restricciones

1.	El estudiante podrá visualizar sus apuntes del curso, así como repositorios relacionados al contexto del curso. No Podrá hacer uso de internet y búsquedas de código a través del navegador.
2.	El estudiante no podrá hacer uso de ningún tipo de herramienta relacionada con IA Generativa como lo son: Chat GPT, Gemini, Copilot, Claude y similares. 
3.	El estudiante no podrá hacer uso de ningún dispositivo electrónico además del computador del laboratorio para realizar la evaluación.

> ⚠️ **Nota importante:**  
>De realizar alguna acción no permitida se anulará el examen y se hará el respectivo reporte al departamento para iniciar un proceso disciplinario.

# Pocket Manager

Sistema de gestión de bolsillos virtuales para cuentas bancarias digitales

## Contexto de la asignación

Eres parte del equipo de desarrollo de un banco digital.
La gerencia te ha solicitado construir una aplicación llamada Pocket Manager, cuyo propósito es permitir a los usuarios organizar su dinero en diferentes “bolsillos virtuales” (pockets) dentro de su cuenta principal.

Cada usuario posee una cuenta principal (MainAccount) con un saldo total y un saldo disponible.
A partir de este saldo, el usuario puede crear bolsillos (Pocket) que representan fondos separados para propósitos específicos (ahorros, gastos, metas, etc.).

## 🎯 Objetivos del sistema

El sistema debe permitir que los usuarios:

- Creen bolsillos (pockets) con un nombre y un monto inicial, que se descuente del saldo disponible de la cuenta principal.

- Depósiten dinero en un bolsillo, transfiriendo fondos desde la cuenta principal.

- Retiren dinero de un bolsillo, devolviendo fondos a la cuenta principal.

- Depositar saldo a la cuenta principal.

- Consulten el estado actual de su cuenta principal y de todos sus bolsillos.


## ⚙️ Arquitectura general

### Modelo propuesto

Tenga en cuenta que el siguiente diagrama es una propuesta, usted puede hacer las modificaciones que considere necesarias.

![alt text](image.png)

El sistema se basa en un servidor TCP que escucha solicitudes en formato JSON en un puerto (por defecto, **5000**) y responde con mensajes en el mismo formato.

Cada cliente se conecta a través de un Socket y envía una petición con una acción (action) y un conjunto de datos (data).

Ejemplo de solicitud añadir bolsillo
```json
{
  "action": "ADD_POCKET",
  "data": {
    "name": "Vacaciones",
    "initialAmount": "1000.0"
  }
}
// respuesta esperada
{
  "status": "ok",
  "data": {
    "name": "Vacaciones",
    "balance": 1000.0,
    "mainAccount": {
      "availableBalance": 4000.0,
      "totalBalance": 5000.0
    }
  }
}
```

Ejemplo de solicitud depositar en bolsillo
```json
{
  "action": "DEPOSIT_POCKET",
  "data": {
    "name": "Vacaciones",
    "amount": "1000.0"
  }
}
// respuesta esperada
{
  "status": "ok",
  "data": {
    "name": "Vacaciones",
    "balance": 1000.0,
    "mainAccount": {
      "availableBalance": 4000.0,
      "totalBalance": 5000.0
    }
  }
}
```

Ejemplo de solicitud retirar de bolsillo
```json
{
  "action": "WITHDRAW_POCKET",
  "data": {
    "name": "Vacaciones",
    "amount": "1000.0"
  }
}
// respuesta esperada
{
  "status": "ok",
  "data": {
    "name": "Vacaciones",
    "balance": 1000.0,
    "mainAccount": {
      "availableBalance": 4000.0,
      "totalBalance": 5000.0
    }
  }
}
```

Ejemplo de solicitud obtener cuenta
```json
{
  "action": "GET_ACCOUNT",
  "data": {
  }
}
// respuesta esperada
{
  "status": "ok",
  "data": {
    "availableBalance": 4000.0,
    "totalBalance": 5000.0,
    "pockets": [{
        "name": "Vacaciones",
        "balance": 1000.0
    }]
  }
}

```


Ejemplo de solicitud depositar en cuenta
```json
{
  "action": "DEPOSIT_ACCOUNT",
  "data": {
    "amount":"200"
  }
}
// respuesta esperada
{
  "status": "ok",
  "data": {
    "availableBalance": 4000.0,
    "totalBalance": 5000.0,
    "pockets": [{
        "name": "Vacaciones",
        "balance": 1000.0
    }]
  }
}
```


### Ejecución

1. Ejecutar las pruebas con Gradle o JUnit

    Con Gradle:
    
```bash
./gradlew test
```

2. Con JUnit directamente (si usas VS Code o IntelliJ, puedes correr PocketServiceTest desde el IDE).

## Criterios de evaluación


| **Criterio**             | **Descripción**                                                                                 | **Peso** |
|---------------------------|------------------------------------------------------------------------------------------------|-----------|
| **Funcionalidad básica y calidad de código**  | Creación, depósito, retiro y consulta de bolsillos. Manteniendo una estructura clara y ordenada y gestionando correctamento los errores.                                        | 40%       |
| **Persistencia y consistencia** | Los datos de los bolsillos se persisten con JDBC de manera consistente       | 10%       |
| **Concurrencia**          | El servidor usa hilos para atender multiples clientes y maneja la sincronización de accesos concurrentes   | 10%       |
| **Pruebas** | Porcentaje de pruebas que pasan * 5                      | 40%       |
