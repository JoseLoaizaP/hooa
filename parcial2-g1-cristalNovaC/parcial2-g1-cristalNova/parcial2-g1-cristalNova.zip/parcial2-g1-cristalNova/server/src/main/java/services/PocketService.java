package services;

import daos.MainAccountDao;
import daos.PocketDao;
import model.MainAccount;
import model.Pocket;

public class PocketService {

    private MainAccount mainAccount;
    private PocketDao pocketDao;
    private MainAccountDao mainAccountDao;

    public PocketService(double initialAmount) {
        this.pocketDao = new PocketDao();
        this.mainAccountDao = new MainAccountDao();
        
        // Intentar cargar la cuenta existente
        this.mainAccount = mainAccountDao.find();
        
        if (this.mainAccount == null) {
            // Si no existe, crear una nueva
            this.mainAccount = new MainAccount();
            this.mainAccount.setAvailableBalance(initialAmount);
            this.mainAccount.setTotalBalance(initialAmount);
            mainAccountDao.save(this.mainAccount);
        }
        
        // Cargar los pockets existentes
        this.mainAccount.setPockets(pocketDao.findAll());
    }

    public synchronized Pocket addPocket(String name, double initialAmount) throws Exception {
        if (initialAmount > mainAccount.getAvailableBalance()) {
            throw new Exception("Insufficient funds in main account");
        }
        
        // Verificar si ya existe un pocket con ese nombre
        Pocket existingPocket = pocketDao.finById(name);
        if (existingPocket != null) {
            throw new Exception("Pocket with name '" + name + "' already exists");
        }
        
        // Crear el pocket
        Pocket pocket = new Pocket();
        pocket.setName(name);
        pocket.setBalance(initialAmount);
        
        // Actualizar saldo disponible de la cuenta principal
        mainAccount.setAvailableBalance(mainAccount.getAvailableBalance() - initialAmount);
        
        // Guardar en base de datos
        pocketDao.save(pocket);
        mainAccountDao.update(mainAccount);
        
        // Actualizar la lista de pockets
        mainAccount.setPockets(pocketDao.findAll());
        
        // Agregar referencia a la cuenta principal
        pocket.setMainAccount(mainAccount);
        
        return pocket;
    }

    public synchronized Pocket depositInPocket(String name, double amount) throws Exception {
        if (amount > mainAccount.getAvailableBalance()) {
            throw new Exception("Insufficient funds in main account");
        }
        
        Pocket pocket = pocketDao.finById(name);
        if (pocket == null) {
            throw new Exception("Pocket not found");
        }
        
        // Actualizar balances
        pocket.setBalance(pocket.getBalance() + amount);
        mainAccount.setAvailableBalance(mainAccount.getAvailableBalance() - amount);
        
        // Guardar en base de datos
        pocketDao.update(pocket);
        mainAccountDao.update(mainAccount);
        
        // Agregar referencia a la cuenta principal
        pocket.setMainAccount(mainAccount);
        
        return pocket;
    }

    public synchronized Pocket withdrawFromPocket(String name, double amount) throws Exception {
        Pocket pocket = pocketDao.finById(name);
        if (pocket == null) {
            throw new Exception("Pocket not found");
        }
        
        if (amount > pocket.getBalance()) {
            throw new Exception("Insufficient funds in pocket");
        }
        
        // Actualizar balances
        pocket.setBalance(pocket.getBalance() - amount);
        mainAccount.setAvailableBalance(mainAccount.getAvailableBalance() + amount);
        
        // Guardar en base de datos
        pocketDao.update(pocket);
        mainAccountDao.update(mainAccount);
        
        // Agregar referencia a la cuenta principal
        pocket.setMainAccount(mainAccount);
        
        return pocket;
    }

    public synchronized MainAccount depositInAccount(double amount) {
        mainAccount.setAvailableBalance(mainAccount.getAvailableBalance() + amount);
        mainAccount.setTotalBalance(mainAccount.getTotalBalance() + amount);
        
        // Guardar en base de datos
        mainAccountDao.update(mainAccount);
        
        // Actualizar la lista de pockets
        mainAccount.setPockets(pocketDao.findAll());
        
        return mainAccount;
    }

    public synchronized MainAccount getMainAccount() {
        // Recargar pockets desde la base de datos
        mainAccount.setPockets(pocketDao.findAll());
        return mainAccount;
    }

    public synchronized Pocket getPocket(String name) {
        Pocket pocket = pocketDao.finById(name);
        if (pocket != null) {
            pocket.setMainAccount(mainAccount);
        }
        return pocket;
    }
}