package dtos;

import java.util.Map;

public class Request {
    public String action;

    public Map<String, String> data;
}
