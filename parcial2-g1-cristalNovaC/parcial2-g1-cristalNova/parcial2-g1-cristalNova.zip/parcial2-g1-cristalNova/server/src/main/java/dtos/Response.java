package dtos;

import com.google.gson.JsonObject;

public class Response {
    public String status;
    public JsonObject data;
}
