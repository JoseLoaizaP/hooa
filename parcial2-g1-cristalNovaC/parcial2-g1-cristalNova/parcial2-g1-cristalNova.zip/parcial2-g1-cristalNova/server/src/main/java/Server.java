import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;

import com.google.gson.Gson;

import dtos.Request;
import dtos.Response;
import model.MainAccount;
import model.Pocket;
import services.PocketService;

public class Server {

    private PocketService pocketService;
    private Gson gson;

    public static void main(String[] args) throws Exception {
        Server server = new Server();
        server.init(1000.0);
    }

    public void init(Double initialAmount) throws Exception {
        this.gson = new Gson();
        this.pocketService = new PocketService(initialAmount);
        
        ServerSocket serverSocket = new ServerSocket(5000);
        System.out.println("Server started on port 5000");
        
        while (true) {
            Socket socket = serverSocket.accept();
            System.out.println("Client connected: " + socket.getInetAddress());
            
            // Crear un nuevo hilo para cada cliente
            new Thread(() -> handleClient(socket)).start();
        }
    }

    public void handleClient(Socket socket) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            
            String line = reader.readLine();
            if (line != null) {
                Request request = gson.fromJson(line, Request.class);
                Response response = handleRequest(request);
                
                String jsonResponse = gson.toJson(response);
                writer.write(jsonResponse);
                writer.newLine();
                writer.flush();
            }
            
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Response handleRequest(Request request) throws Exception {
        Response response = new Response();
        
        try {
            switch (request.action) {
                case "ADD_POCKET":
                    String name = request.data.get("name");
                    double initialAmount = Double.parseDouble(request.data.get("initialAmount"));
                    Pocket newPocket = pocketService.addPocket(name, initialAmount);
                    response.status = "ok";
                    response.data = gson.toJsonTree(newPocket).getAsJsonObject();
                    break;
                    
                case "DEPOSIT_POCKET":
                    String pocketName = request.data.get("name");
                    double depositAmount = Double.parseDouble(request.data.get("amount"));
                    Pocket depositedPocket = pocketService.depositInPocket(pocketName, depositAmount);
                    response.status = "ok";
                    response.data = gson.toJsonTree(depositedPocket).getAsJsonObject();
                    break;
                    
                case "WITHDRAW_POCKET":
                    String withdrawPocketName = request.data.get("name");
                    double withdrawAmount = Double.parseDouble(request.data.get("amount"));
                    Pocket withdrawnPocket = pocketService.withdrawFromPocket(withdrawPocketName, withdrawAmount);
                    response.status = "ok";
                    response.data = gson.toJsonTree(withdrawnPocket).getAsJsonObject();
                    break;
                    
                case "DEPOSIT_ACCOUNT":
                    double accountDepositAmount = Double.parseDouble(request.data.get("amount"));
                    MainAccount updatedAccount = pocketService.depositInAccount(accountDepositAmount);
                    response.status = "ok";
                    response.data = gson.toJsonTree(updatedAccount).getAsJsonObject();
                    break;
                    
                case "GET_ACCOUNT":
                    MainAccount account = pocketService.getMainAccount();
                    response.status = "ok";
                    response.data = gson.toJsonTree(account).getAsJsonObject();
                    break;
                    
                default:
                    response.status = "error";
                    response.data = gson.toJsonTree(Map.of("error", "Unknown action")).getAsJsonObject();
                    break;
            }
        } catch (Exception e) {
            response.status = "error";
            response.data = gson.toJsonTree(Map.of("message", e.getMessage())).getAsJsonObject();
        }
        
        return response;
    }
}